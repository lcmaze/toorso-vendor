export const environment = {
  production: true,
  apiUrl: 'https://futhub.in/toorso/',
  cdnLink: 'https://cdn.litsonthomas.com/toorso/'
};
