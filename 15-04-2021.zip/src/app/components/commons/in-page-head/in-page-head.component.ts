import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-page-head',
  templateUrl: './in-page-head.component.html',
  styleUrls: ['./in-page-head.component.scss']
})
export class InPageHeadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
