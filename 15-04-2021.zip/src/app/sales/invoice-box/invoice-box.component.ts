import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-box',
  templateUrl: './invoice-box.component.html',
  styleUrls: ['./invoice-box.component.scss']
})
export class InvoiceBoxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
